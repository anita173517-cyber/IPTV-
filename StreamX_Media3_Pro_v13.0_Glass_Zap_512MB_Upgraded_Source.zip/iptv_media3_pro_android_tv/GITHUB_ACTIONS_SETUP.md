# Build the single APK from GitHub Actions

1. Create or open your GitHub repository.
2. Upload `StreamX_Media3_Pro_v13.0_Glass_Zap_512MB_Source.zip` to the repository root and commit it.
3. Open **Actions** → **New workflow** → **set up a workflow yourself**.
4. Replace the editor contents with `StreamX_GitHub_Actions_build_apk.yml` (the separate YAML file supplied with this project).
5. Save/commit the workflow file as `.github/workflows/build_apk.yml`.
6. Open **Actions** → **StreamX Media3 Pro - Single Release APK** → **Run workflow**.
7. Wait for the job to finish. Open the successful run and download the artifact named `StreamX-Media3-Pro-v13.0-Glass-Zap-Single-Release`.

The workflow extracts the ZIP, installs JDK 17 / Android SDK 36 / Gradle 8.13, runs source verification and unit tests, builds `assembleRelease`, checks the APK archive, and uploads one APK artifact.

**Important:** GitHub does not activate a workflow that is still stored inside an unextracted ZIP. That is why step 4 is required when the repository initially contains only the ZIP.

A successful structural check in this archive is not the same as a successful Android build. The APK is considered build-verified only after the GitHub Actions run completes successfully. Device-specific playback and performance still need testing on the actual TV.

## App update/signing note

For updates over an already installed APK, Android requires the same signing key as the installed version. If you possess the original release keystore, add these four GitHub repository Actions secrets: `ANDROID_KEYSTORE_BASE64`, `ANDROID_KEYSTORE_PASSWORD`, `ANDROID_KEY_ALIAS`, and `ANDROID_KEY_PASSWORD`. The workflow supports them.

If the old workflow generated a temporary runner-only debug key and you do not have that exact key, the new APK cannot be installed as an in-place update. You will need to uninstall the old app before installing this build; uninstalling normally clears that app's locally stored profiles and settings. Export/record any playlist/profile details you need first.
