package com.harindra.iptvpro

import java.io.BufferedReader
import java.io.Reader
import java.io.StringReader
import java.util.Locale

object M3uParser {
    private const val DEFAULT_MAX_CHANNELS = 60_000
    private const val FIRST_BATCH_SIZE = 80 // Emit the first 80 channels early for progressive loading

    private fun extractAttributeFast(line: String, attrName: String): String {
        val keyIdx = line.indexOf(attrName, startIndex = 8, ignoreCase = true)
        if (keyIdx < 0) return ""
        var i = keyIdx + attrName.length
        val len = line.length
        while (i < len && line[i].isWhitespace()) i++
        if (i >= len || line[i] != '=') return ""
        i++
        while (i < len && line[i].isWhitespace()) i++
        if (i >= len) return ""
        val quote = line[i]
        if (quote != '"' && quote != '\'') return ""
        val start = i + 1
        val end = line.indexOf(quote, startIndex = start)
        return if (end > start) line.substring(start, end).trim() else ""
    }

    private fun fnv1a64(str: String): Long {
        var hash = -0x340d631b7bdddcdbL
        for (i in 0 until str.length) {
            hash = hash xor str[i].code.toLong()
            hash *= 0x100000001b3L
        }
        return hash
    }

    private fun normalizeChannelKey(name: String, group: String): String {
        return "${group.trim().lowercase(Locale.ROOT)}|${name.trim().lowercase(Locale.ROOT)}"
    }

    fun parse(
        m3uContent: String,
        maxChannels: Int = DEFAULT_MAX_CHANNELS,
        shouldCancel: () -> Boolean = { false },
        onFirstBatch: ((List<Channel>) -> Unit)? = null
    ): List<Channel> {
        return parse(StringReader(m3uContent.removePrefix("\uFEFF")), maxChannels, shouldCancel, onFirstBatch)
    }

    fun parse(
        reader: Reader,
        maxChannels: Int = DEFAULT_MAX_CHANNELS,
        shouldCancel: () -> Boolean = { false },
        onFirstBatch: ((List<Channel>) -> Unit)? = null
    ): List<Channel> {
        val channels = ArrayList<Channel>(2048)
        val categoryPool = HashMap<String, String>(128)
        val seenUrlHashes = HashSet<Long>(4096)
        val primaryIndexByNormName = HashMap<String, Int>(2048)

        var pendingName = ""
        var pendingGroup = "General"
        var pendingLogo = ""
        var pendingId = ""
        var number = 1
        var lineCounter = 0
        var firstBatchEmitted = false

        val buffered = if (reader is BufferedReader) reader else BufferedReader(reader, 32768)
        var rawLine: String? = buffered.readLine()
        while (rawLine != null) {
            lineCounter++
            if (lineCounter % 1500 == 0 && shouldCancel()) {
                break
            }
            val line = rawLine.trim().let { if (lineCounter == 1) it.removePrefix("\uFEFF") else it }
            if (line.isNotEmpty()) {
                when {
                    line.startsWith("#EXTINF:", ignoreCase = true) -> {
                        val comma = line.lastIndexOf(',')
                        pendingName = if (comma >= 0 && comma < line.lastIndex) {
                            line.substring(comma + 1).trim()
                        } else {
                            "Channel $number"
                        }
                        val rawGroup = extractAttributeFast(line, "group-title").ifBlank { "General" }
                        pendingGroup = categoryPool.getOrPut(rawGroup) { rawGroup }
                        pendingLogo = extractAttributeFast(line, "tvg-logo")
                        pendingId = extractAttributeFast(line, "tvg-id")
                    }
                    line.startsWith("#EXTGRP:", ignoreCase = true) -> {
                        val rawGroup = line.substringAfter(':').trim().ifBlank { "General" }
                        pendingGroup = categoryPool.getOrPut(rawGroup) { rawGroup }
                    }
                    !line.startsWith("#") && (
                        line.startsWith("http://", ignoreCase = true) ||
                            line.startsWith("https://", ignoreCase = true) ||
                            line.startsWith("rtsp://", ignoreCase = true) ||
                            line.startsWith("rtmp://", ignoreCase = true)
                        ) -> {
                        if (seenUrlHashes.add(fnv1a64(line))) {
                            val resolvedName = pendingName.ifBlank { "Channel $number" }
                            val normKey = normalizeChannelKey(resolvedName, pendingGroup)
                            val existingIdx = primaryIndexByNormName[normKey]
                            if (existingIdx != null && existingIdx in channels.indices && channels[existingIdx].backupUrl.isEmpty()) {
                                val primary = channels[existingIdx]
                                channels[existingIdx] = primary.copy(backupUrl = line)
                            } else {
                                val newIdx = channels.size
                                channels.add(
                                    Channel(
                                        id = if (pendingId.isNotEmpty()) "${pendingId}_$number" else "m3u_$number",
                                        number = number,
                                        name = resolvedName,
                                        category = pendingGroup,
                                        streamUrl = line,
                                        logoUrl = pendingLogo,
                                        epgId = pendingId
                                    )
                                )
                                primaryIndexByNormName.putIfAbsent(normKey, newIdx)
                                number++
                                if (!firstBatchEmitted && channels.size == FIRST_BATCH_SIZE && onFirstBatch != null) {
                                    firstBatchEmitted = true
                                    onFirstBatch(ArrayList(channels))
                                }
                                if (channels.size >= maxChannels) break
                            }
                        }
                        pendingName = ""
                        pendingGroup = "General"
                        pendingLogo = ""
                        pendingId = ""
                    }
                }
            }
            rawLine = buffered.readLine()
        }
        return channels
    }
}
