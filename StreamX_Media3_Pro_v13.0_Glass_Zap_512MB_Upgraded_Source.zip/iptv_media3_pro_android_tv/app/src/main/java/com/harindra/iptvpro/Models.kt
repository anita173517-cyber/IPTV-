package com.harindra.iptvpro

/**
 * Ultra-lean Channel model for <=512 MB RAM Android Smart TVs (v12.0 Quantum-Lite).
 * Includes optional backupUrl for instant auto-failover when duplicate channel names exist (Upgrade 8).
 */
data class Channel(
    val id: String,
    val number: Int,
    val name: String,
    val category: String,
    val streamUrl: String,
    val logoUrl: String = "",
    val epgId: String = "",
    val backupUrl: String = ""
) {
    companion object {
        const val DEFAULT_PROGRAM = "Live Broadcast"
        const val DEFAULT_NEXT_PROGRAM = "Upcoming Show"
    }
}

data class XtreamCredentials(
    val profileName: String,
    val serverUrl: String,
    val username: String,
    val password: String
)
