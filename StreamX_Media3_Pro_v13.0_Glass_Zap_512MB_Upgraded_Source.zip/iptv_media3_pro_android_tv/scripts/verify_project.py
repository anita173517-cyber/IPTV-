#!/usr/bin/env python3
"""Offline structural checks for the StreamX Android source project."""
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
errors = []
required = [
    root / "settings.gradle.kts",
    root / "build.gradle.kts",
    root / "app/build.gradle.kts",
    root / "app/src/main/AndroidManifest.xml",
    root / "app/src/main/res/layout/activity_player.xml",
    root / "app/src/main/java/com/harindra/iptvpro/PlayerActivity.kt",
    root / "app/src/main/java/com/harindra/iptvpro/NetworkClient.kt",
]
for path in required:
    if not path.is_file():
        errors.append(f"Missing required file: {path.relative_to(root)}")

for path in (root / "app/src/main").rglob("*.xml"):
    try:
        ET.parse(path)
    except ET.ParseError as exc:
        errors.append(f"Invalid XML {path.relative_to(root)}: {exc}")

build = (root / "app/build.gradle.kts").read_text()
if 'val media3Version = "1.11.1"' not in build:
    errors.append("Media3 dependency version is not pinned to 1.11.1")
if len(re.findall(r'implementation\("androidx\.media3:', build)) != 7:
    errors.append("Expected all seven Media3 modules to use the shared 1.11.1 version variable")
if "minSdk = 23" not in build:
    errors.append("minSdk compatibility declaration is missing")

manifest = (root / "app/src/main/AndroidManifest.xml").read_text()
if 'android:largeHeap="true"' in manifest:
    errors.append("largeHeap must remain disabled for the 512MB low-RAM target")

player = (root / "app/src/main/java/com/harindra/iptvpro/PlayerActivity.kt").read_text()
if "EXTENSION_RENDERER_MODE_OFF" not in player:
    errors.append("Optional extension decoders should be disabled on the 512MB profile")
if "scheduleTop8Warmup(this@PlayerActivity" in player:
    errors.append("Top-eight speculative warmup must not run during active playback")
for token in ("onRenderedFirstFrame", "dismissBootSafetyRunnable", "setBackBuffer(0, false)", "setAudioAttributes(", "setHandleAudioBecomingNoisy(true)"):
    if token not in player:
        errors.append(f"Missing expected playback behavior: {token}")

network = (root / "app/src/main/java/com/harindra/iptvpro/NetworkClient.kt").read_text()
for token in ("metadataDispatcher", "apiDispatcher", "streamDispatcher", "readTimeout(20, TimeUnit.SECONDS)"):
    if token not in network:
        errors.append(f"Missing expected network isolation behavior: {token}")

if errors:
    print("FAIL")
    print("\\n".join(f" - {e}" for e in errors))
    sys.exit(1)

print("PASS: required project files present")
print("PASS: all Android XML resources parse")
print("PASS: Media3 artifacts consistently pinned to 1.11.1")
print("PASS: startup, playback, and isolated network configuration markers present")
